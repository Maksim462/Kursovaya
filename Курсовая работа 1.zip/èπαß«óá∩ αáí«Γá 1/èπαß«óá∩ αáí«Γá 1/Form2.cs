﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;
using System.Data.Sql;

namespace Курсовая_работа_1
{

    public partial class Form2 : Form
    {

        public Form2()
        {
            InitializeComponent();
        }
        public Form2(Form4 form4)
        {
            InitializeComponent();
            this.form4 = form4;
        }

        SqlConnection con;
        SqlDataAdapter ad;
        SqlCommand cmd;
        DataSet ds;
        private Form4 form4;

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            //Добавление данных в таблицу животные
            //https://techarks.ru/qa/csharp/kak-dobavit-stroku-v-datagr-U2/
            //Добавление данных в таблицу клиент
            //Добавление в таблицу заявка- не указывать id worker, id veterinar, дата посещения,сохранить в переменную id созданной заявки 
        }

        private void button3_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(@"Data Source = 10.10.1.24; Initial Catalog = KursPro-41; User ID = pro-41; Password = Pro_41student"))
            {
                connection.Open();
                SqlCommand command = new SqlCommand("INSERT INTO Animal VALUES(@Clichka,@Vidanimal,@Porodaanimal,@dateofbirhday)", connection);

                command.Parameters.AddWithValue("@Clichka", textBox7.Text);
                command.Parameters.AddWithValue("@Vidanimal", textBox8.Text);
                command.Parameters.AddWithValue("@Porodaanimal", textBox9.Text);
                command.Parameters.AddWithValue("@dateofbirhday", textBox10.Text);

                SqlCommand commands = new SqlCommand("INSERT INTO Client VALUES(@Otchestvo,@Name,@Familiya,@Mail,@Telephone,@Datebirhday)", connection);
                commands.Parameters.AddWithValue("@Otchestvo", textBox1.Text);
                commands.Parameters.AddWithValue("@Name", textBox2.Text);
                commands.Parameters.AddWithValue("@Familiya", textBox3.Text);
                commands.Parameters.AddWithValue("@Mail", textBox4.Text);
                commands.Parameters.AddWithValue("@Telephone", textBox5.Text);
                commands.Parameters.AddWithValue("@Datebirhday", textBox6.Text);
                command.ExecuteNonQuery();
                MessageBox.Show("Информация о питомце отправлена, обязательно отправьте заявку!");
                connection.Close();
            }

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(@"Data Source = 10.10.1.24; Initial Catalog = KursPro-41; User ID = pro-41; Password = Pro_41student"))
            {
                SqlCommand commands = new SqlCommand("INSERT INTO Client VALUES(@Otchestvo,@Name,@Familiya,@Mail,@Telephone,@Datebirhday)", connection);
                commands.Parameters.AddWithValue("@Otchestvo", textBox1.Text);
                commands.Parameters.AddWithValue("@Name", textBox2.Text);
                commands.Parameters.AddWithValue("@Familiya", textBox3.Text);
                commands.Parameters.AddWithValue("@Mail", textBox4.Text);
                commands.Parameters.AddWithValue("@Telephone", textBox5.Text);
                commands.Parameters.AddWithValue("@Datebirhday", textBox6.Text);
                commands.ExecuteNonQuery();
                MessageBox.Show("Заявка отправлена ожидайте ответа по почте!");
             }

        }
    }
}
