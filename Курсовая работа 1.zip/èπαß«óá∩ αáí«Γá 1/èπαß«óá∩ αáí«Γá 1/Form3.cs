﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace Курсовая_работа_1
{
    public partial class Form3 : Form
    {
        [Serializable]
        public class Users
        {
            public List<string> Logins = new List<string>();
            public List<string> Passwords = new List<string>();
        }
        public string login = string.Empty;
        public string password = string.Empty;
        private Users user = new Users();
        public Form3()
        {
            InitializeComponent();

            LoadUsers();
        }
        private void LoadUsers()
        {
            try
            {
                FileStream fs = new FileStream("Users.dat", FileMode.Open);
                BinaryFormatter formatter = new BinaryFormatter();
                user = (Users)formatter.Deserialize(fs);
                fs.Close();
            }
            catch { return; }
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < user.Logins.Count; i++)
            {
                if (user.Logins[i] == textBox1.Text && user.Passwords[i]==textBox2.Text)
                {
                    login = user.Logins[i];
                    password = user.Passwords[i];
                    MessageBox.Show("Успешный вход в систему!");
                    this.Close();
                }
                else if (user.Logins[i] == textBox1.Text && textBox2.Text !=user.Passwords[i])
                {
                    login = user.Logins[i];
                    MessageBox.Show("Не тот пароль!");
                }

            }
            if (login =="") { MessageBox.Show("Менеджер " + textBox1.Text + " Не существует"); }
            Form4 Kop = new Form4();
            Kop.Show();
        }
        private void AddUser()
        { 
            if (textBox1.Text=="" || textBox2.Text=="") { MessageBox.Show("Не был введен логин или пароль!");return; }
            user.Logins.Add(textBox1.Text);
            user.Passwords.Add(textBox2.Text);
            FileStream fs = new FileStream("Users.dat", FileMode.OpenOrCreate);
            BinaryFormatter formatter = new BinaryFormatter();
            formatter.Serialize(fs, user);
            fs.Close();
            login = textBox1.Text;
            this.Close();
        }
        private void Form3_Form3Closed(Object sender, FormClosedEventArgs e)
        {
            if (login=="" | password=="") { Application.Exit(); }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            AddUser();
        }
    }
}
