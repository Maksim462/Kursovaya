﻿
namespace Курсовая_работа_1
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this._KursPro_41DataSet = new Курсовая_работа_1._KursPro_41DataSet();
            this.animalBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.animalTableAdapter = new Курсовая_работа_1._KursPro_41DataSetTableAdapters.AnimalTableAdapter();
            this._KursPro_41DataSet1 = new Курсовая_работа_1._KursPro_41DataSet1();
            this.animalBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.animalTableAdapter1 = new Курсовая_работа_1._KursPro_41DataSet1TableAdapters.AnimalTableAdapter();
            this._KursPro_41DataSet2 = new Курсовая_работа_1._KursPro_41DataSet2();
            this.animalBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.animalTableAdapter2 = new Курсовая_работа_1._KursPro_41DataSet2TableAdapters.AnimalTableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this._KursPro_41DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.animalBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._KursPro_41DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.animalBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._KursPro_41DataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.animalBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(713, 415);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Выход";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(208, 326);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(108, 34);
            this.button2.TabIndex = 4;
            this.button2.Text = "Показать таблицы";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(571, 327);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(85, 33);
            this.button3.TabIndex = 5;
            this.button3.Text = "Эксперимент";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // _KursPro_41DataSet
            // 
            this._KursPro_41DataSet.DataSetName = "_KursPro_41DataSet";
            this._KursPro_41DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // animalBindingSource
            // 
            this.animalBindingSource.DataMember = "Animal";
            this.animalBindingSource.DataSource = this._KursPro_41DataSet;
            // 
            // animalTableAdapter
            // 
            this.animalTableAdapter.ClearBeforeFill = true;
            // 
            // _KursPro_41DataSet1
            // 
            this._KursPro_41DataSet1.DataSetName = "_KursPro_41DataSet1";
            this._KursPro_41DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // animalBindingSource1
            // 
            this.animalBindingSource1.DataMember = "Animal";
            this.animalBindingSource1.DataSource = this._KursPro_41DataSet1;
            // 
            // animalTableAdapter1
            // 
            this.animalTableAdapter1.ClearBeforeFill = true;
            // 
            // _KursPro_41DataSet2
            // 
            this._KursPro_41DataSet2.DataSetName = "_KursPro_41DataSet2";
            this._KursPro_41DataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // animalBindingSource2
            // 
            this.animalBindingSource2.DataMember = "Animal";
            this.animalBindingSource2.DataSource = this._KursPro_41DataSet2;
            // 
            // animalTableAdapter2
            // 
            this.animalTableAdapter2.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(208, 82);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(448, 217);
            this.dataGridView1.TabIndex = 6;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Form4";
            this.Text = "Form4";
            this.Load += new System.EventHandler(this.Form4_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this._KursPro_41DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.animalBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._KursPro_41DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.animalBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._KursPro_41DataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.animalBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private _KursPro_41DataSet _KursPro_41DataSet;
        private System.Windows.Forms.BindingSource animalBindingSource;
        private _KursPro_41DataSetTableAdapters.AnimalTableAdapter animalTableAdapter;
        private _KursPro_41DataSet1 _KursPro_41DataSet1;
        private System.Windows.Forms.BindingSource animalBindingSource1;
        private _KursPro_41DataSet1TableAdapters.AnimalTableAdapter animalTableAdapter1;
        private _KursPro_41DataSet2 _KursPro_41DataSet2;
        private System.Windows.Forms.BindingSource animalBindingSource2;
        private _KursPro_41DataSet2TableAdapters.AnimalTableAdapter animalTableAdapter2;
        public System.Windows.Forms.DataGridView dataGridView1;
    }
}