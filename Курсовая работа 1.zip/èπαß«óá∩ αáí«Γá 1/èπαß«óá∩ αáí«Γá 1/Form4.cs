﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;

namespace Курсовая_работа_1
{
    //Получить переменную с   id заявки, написать код для изменения этой заявки- добавить ветеринара,дата посещения и менеджера
    public partial class Form4 : Form
    {
        private Form4 form4;
        Form3 registrationForm = new Form3();
        public Form4()
        {
            InitializeComponent();
            registrationForm.ShowDialog();
            
        }
        SqlDataAdapter ZayvkaAdapter;
        SqlDataAdapter VeterinarAdapter;
        SqlDataAdapter EmloyeeAdatper;
        DataSet ds;
        string cur = "";
        private void Form4_load(object sender, EventArgs e)
        {
            string connStr = "Data Source=10.10.1.24;Initial Catalog=KursPro-41;User ID=Pro-41;Password=Pro_41student";
            string cmdStr = "select * from Zayavka";
            string cmdStr2 = "select * from Employee";
            string cmdStr3 = "select * from veterinar";
            SqlConnection conn = new SqlConnection(connStr);
            try
            {
                conn.Open();
                ZayvkaAdapter = new SqlDataAdapter(cmdStr, conn);
                ds = new DataSet();
                ZayvkaAdapter.Fill(ds, "Zayavka");
                SqlCommandBuilder builder = new SqlCommandBuilder(ZayvkaAdapter);
                ZayvkaAdapter.UpdateCommand = builder.GetUpdateCommand();
            }
            catch (MySqlException exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ds.Tables["Zayavka"];
            dataGridView1.Columns[0].HeaderText = "ID_zayavka";
            dataGridView1.Columns[1].HeaderText = "ID_worker";
            dataGridView1.Columns[0].Visible = true;
            cur = "Zayavka";
        }
        private void button3_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2(this);
            frm2.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form4_Load_1(object sender, EventArgs e)
        {


        }
    }
}
